# Integration reference

## Create a payment request

```bash
curl -X POST "https://console.zividax.uk/public/api/v1/payments/request" \
  -H "Authorization: Bearer zx_live_your_key_here" \
  -H "Idempotency-Key: order_12345" \
  -H "Content-Type: application/json" \
  -d '{
    "customer_username": "customer_username",
    "company_name": "XYZ Company",
    "service_name": "Premium Subscription",
    "request_type": "subscription",
    "amount": 1.00,
    "description": "Monthly premium plan",
    "reference": "ORDER-12345",
    "return_url": "https://example.com/payment-complete"
  }'
```

Supported request types:

`subscription`, `donation`, `purchase`, `wallet_topup`, `service`, `other`

## Check payment status

```bash
curl -G "https://console.zividax.uk/public/api/v1/payments/status" \
  -H "Authorization: Bearer zx_live_your_key_here" \
  --data-urlencode "request_id=ZPR-..."
```

Never call these protected endpoints directly from browser JavaScript. Proxy through your server.
